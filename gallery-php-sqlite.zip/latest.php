<?php
// latest.php
require_once 'config.php'; // Reuse your configuration file

$pdo = get_db_connection();
$base_url = rtrim(UPLOAD_DIR, '/');

// SQL to fetch ONLY the 3 latest images
$images_stmt = $pdo->prepare("SELECT filename FROM images ORDER BY uploaded_at DESC LIMIT 6");
$images_stmt->execute();
$images = $images_stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latest Photos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
    <style>
        .latest-photo img {
            height: 250px;
            object-fit: cover;
            width: 100%;
        }
    </style>
</head>
<body>

<div class="container my-5">
    <h1 class="mb-4">🌟 Latest Photos</h1>

    <div class="row g-4 mb-4">
        <?php if (count($images) > 0): ?>
            <?php foreach ($images as $img):
                $image_path = $base_url . '/' . htmlspecialchars($img['filename']);
            ?>
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="latest-photo card shadow-sm">
                        <a href="<?php echo $image_path; ?>" target="_blank">
                            <img src="<?php echo $image_path; ?>" class="card-img-top" alt="Latest Photo">
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center">
                <p>No photos have been uploaded yet.</p>
            </div>
        <?php endif; ?>
    </div>

    <div class="text-center mt-5">
        <a href="index.php" class="btn btn-lg btn-primary shadow-sm">
            <i class="fa-solid fa-images"></i> View More Photos in Gallery
        </a>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
