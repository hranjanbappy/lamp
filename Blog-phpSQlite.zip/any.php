<?php
require 'config.php';

// Check if we are filtering by category
$category = isset($_GET['category']) ? $_GET['category'] : null;

if ($category) {
    $stmt = $pdo->prepare("SELECT * FROM posts WHERE category = ? ORDER BY created_at DESC");
    $stmt->execute([$category]);
    $posts = $stmt->fetchAll();
    $pageTitle = "Category: " . htmlspecialchars($category);
} else {
    $stmt = $pdo->query("SELECT * FROM posts ORDER BY created_at DESC");
    $posts = $stmt->fetchAll();
    $pageTitle = "Recent Posts";
}

// Get all unique categories for the sidebar/menu
$catStmt = $pdo->query("SELECT DISTINCT category FROM posts ORDER BY category ASC");
$categories = $catStmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Blog</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <div class="container">
        <nav>
            <h1><a href="index.php">My Awesome Blog</a></h1>
            <div>
                <?php foreach($categories as $cat): ?>
                    <a href="index.php?category=<?= urlencode($cat) ?>"><?= htmlspecialchars($cat) ?></a>
                <?php endforeach; ?>
                <a href="admin.php" style="background: rgba(255,255,255,0.2); padding: 5px 10px; border-radius: 4px;">Admin</a>
            </div>
        </nav>
    </div>
</header>

<div class="container">
    <?php if($category): ?>
        <div class="archive-header">
            <h2>Browsing Category: <?= htmlspecialchars($category) ?></h2>
            <a href="index.php" style="color: #777; text-decoration: none;">&larr; Back to all posts</a>
        </div>
    <?php endif; ?>

    <div class="blog-grid">
        <?php if (count($posts) > 0): ?>
            <?php foreach ($posts as $post): ?>
                <div class="post-card">

                    <?php if($post['thumbnail']): ?>
                        <a href="post.php?id=<?= $post['id'] ?>"><img src="<?= htmlspecialchars($post['thumbnail']) ?>" alt="Thumbnail" class="post-thumbnail"></a>
                    <?php else: ?>
                        <a style="text-decoration:none;" href="post.php?id=<?= $post['id'] ?>"><div class="post-thumbnail" style="display:flex;align-items:center;justify-content:center;color:#999;">No Image</div></a>
                    <?php endif; ?>

                    <div class="post-content">
                        <div class="post-meta">
                            <a href="index.php?category=<?= urlencode($post['category']) ?>" class="category-tag"><?= htmlspecialchars($post['category']) ?></a>
                            &nbsp; <?= date('M d, Y', strtotime($post['created_at'])) ?>
                        </div>
                        <h2 class="post-title">
                            <a href="post.php?id=<?= $post['id'] ?>"><?= htmlspecialchars($post['title']) ?></a>
                        </h2>
                        <p><?= substr(strip_tags($post['body']), 0, 100) ?>...</p>
                        <a href="post.php?id=<?= $post['id'] ?>" class="read-more">Read Article &rarr;</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No posts found. <a href="admin.php">Login to create one!</a></p>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
