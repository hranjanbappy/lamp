<?php
// config.php

// Database configuration
define('DB_PATH', __DIR__ . '/photos.db');
define('IMAGES_PER_PAGE', 4); // Images to show per page for both front-end and admin
define('UPLOAD_DIR', 'gallery/');

/**
 * Get the SQLite PDO connection object.
 * @return PDO
 */
function get_db_connection() {
    try {
        // Create a PDO connection to the SQLite database
        $pdo = new PDO('sqlite:' . DB_PATH);
        // Set error mode to exceptions for better error handling
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }
}

/**
 * Initializes the database table if it doesn't exist.
 */
function init_db() {
    $pdo = get_db_connection();
    // SQL to create the 'images' table
    $sql = "
        CREATE TABLE IF NOT EXISTS images (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
    ";
    $pdo->exec($sql);
}

/**
 * Calculates pagination details.
 * @param int $total_items Total number of items.
 * @param int $current_page The current page number.
 * @param int $items_per_page Items to display per page.
 * @return array
 */
function get_pagination_details($total_items, $current_page, $items_per_page) {
    $total_pages = ceil($total_items / $items_per_page);
    $offset = ($current_page - 1) * $items_per_page;
    $offset = max(0, $offset); // Ensure offset is not negative

    return [
        'total_pages' => $total_pages,
        'current_page' => $current_page,
        'offset' => $offset
    ];
}

// Ensure the gallery directory exists
if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0777, true);
}

// Initialize the database and table
init_db();
