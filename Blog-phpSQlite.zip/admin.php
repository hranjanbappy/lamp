<?php
session_start();
require 'config.php';

// --- AUTHENTICATION ---
$admin_user = "admin";
$admin_pass = "password";

// Handle Login
if (isset($_POST['login'])) {
    if ($_POST['username'] === $admin_user && $_POST['password'] === $admin_pass) {
        $_SESSION['logged_in'] = true;
        header("Location: admin.php");
        exit;
    } else {
        $error = "Invalid credentials.";
    }
}

// Handle Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit;
}

// Check if logged in
if (!isset($_SESSION['logged_in'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Login</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="login-box">
            <h2 style="text-align:center;">Admin Login</h2>
            <?php if(isset($error)) echo "<p style='color:red;text-align:center;'>$error</p>"; ?>
            <form method="POST">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit" name="login" class="btn btn-success" style="width:100%;">Login</button>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// --- AJAX IMAGE UPLOAD HANDLER (For Summernote Body Images) ---
if (isset($_GET['upload_image']) && isset($_FILES['file'])) {
    if ($_FILES['file']['error'] == 0) {
        $filename = time() . '_' . basename($_FILES['file']['name']);
        $target_path = 'images/' . $filename;

        if (move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {
            echo $target_path; // Return the URL to the editor
        } else {
            echo 'Error uploading file';
        }
    }
    exit; // Stop script execution here for AJAX requests
}

// --- ADMIN ACTIONS ---

// 1. Handle Post Creation/Update
if (isset($_POST['save_post'])) {
    $title = $_POST['title'];
    $category = $_POST['category'];
    $body = $_POST['body'];
    $thumbnail = $_POST['current_thumbnail'] ?? '';

    // Handle Thumbnail Upload to images/ folder
    if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0) {
        // Create unique name to prevent overwrites
        $filename = time() . '_' . basename($_FILES["thumbnail"]["name"]);
        $target_file = "images/" . $filename;

        if (move_uploaded_file($_FILES["thumbnail"]["tmp_name"], $target_file)) {
            $thumbnail = $target_file;
        }
    }

    if (isset($_POST['post_id']) && !empty($_POST['post_id'])) {
        // Update
        $stmt = $pdo->prepare("UPDATE posts SET title=?, category=?, body=?, thumbnail=? WHERE id=?");
        $stmt->execute([$title, $category, $body, $thumbnail, $_POST['post_id']]);
    } else {
        // Insert
        $stmt = $pdo->prepare("INSERT INTO posts (title, category, body, thumbnail) VALUES (?, ?, ?, ?)");
        $stmt->execute([$title, $category, $body, $thumbnail]);
    }
    header("Location: admin.php");
    exit;
}

// 2. Handle Delete
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    header("Location: admin.php");
    exit;
}

// 3. Determine Mode (Edit or List)
$post_to_edit = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $post_to_edit = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Summernote -->
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>

    <style>
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 20px;
            gap: 5px;
        }
        .pagination a {
            text-decoration: none;
            padding: 5px 10px;
            border: 1px solid #ddd;
            color: #333;
            border-radius: 3px;
            background: white;
        }
        .pagination a.active {
            background: #3498db;
            color: white;
            border-color: #3498db;
        }
        .pagination a:hover:not(.active) {
            background: #f1f1f1;
        }
    </style>
</head>
<body>

<header>
    <div class="container">
        <nav>
            <h1>Admin Panel</h1>
            <div>
                <a href="index.php" target="_blank">View Site</a>
                <a href="admin.php?logout=true">Logout</a>
            </div>
        </nav>
    </div>
</header>

<div class="container">

    <!-- EDITOR SECTION -->
    <div style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 30px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
        <h3><?= $post_to_edit ? 'Edit Post' : 'Create New Post' ?></h3>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="post_id" value="<?= $post_to_edit['id'] ?? '' ?>">
            <input type="hidden" name="current_thumbnail" value="<?= $post_to_edit['thumbnail'] ?? '' ?>">

            <div class="form-group">
                <label>Post Title</label>
                <input type="text" name="title" value="<?= htmlspecialchars($post_to_edit['title'] ?? '') ?>" required>
            </div>

            <div class="form-group">
                <label>Category</label>
                <input type="text" name="category" list="cat_list" value="<?= htmlspecialchars($post_to_edit['category'] ?? '') ?>" required placeholder="e.g. Tech, Lifestyle...">
                <datalist id="cat_list">
                    <?php
                    $cats = $pdo->query("SELECT DISTINCT category FROM posts")->fetchAll(PDO::FETCH_COLUMN);
                    foreach($cats as $c) echo "<option value='$c'>";
                    ?>
                </datalist>
            </div>

            <div class="form-group">
                <label>Thumbnail Image</label>
                <?php if(isset($post_to_edit['thumbnail']) && $post_to_edit['thumbnail']): ?>
                    <img src="<?= $post_to_edit['thumbnail'] ?>" style="height: 50px; display:block; margin-bottom:5px;">
                <?php endif; ?>
                <input type="file" name="thumbnail" accept="image/*">
            </div>

            <div class="form-group">
                <label>Content</label>
                <textarea id="summernote" name="body"><?= $post_to_edit['body'] ?? '' ?></textarea>
            </div>

            <button type="submit" name="save_post" class="btn btn-success">Save Post</button>
            <?php if($post_to_edit): ?>
                <a href="admin.php" class="btn" style="background: #7f8c8d;">Cancel</a>
            <?php endif; ?>
        </form>
    </div>

    <!-- LIST SECTION WITH PAGINATION -->
    <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
        <h3>All Posts</h3>
        <table class="post-table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // --- PAGINATION LOGIC ---
                $page_limit = 10; // Posts per page
                $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
                $offset = ($page - 1) * $page_limit;

                // Get total records
                $total_stmt = $pdo->query("SELECT COUNT(*) FROM posts");
                $total_rows = $total_stmt->fetchColumn();
                $total_pages = ceil($total_rows / $page_limit);

                // Fetch records for current page
                $stmt = $pdo->prepare("SELECT * FROM posts ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
                $stmt->bindValue(':limit', $page_limit, PDO::PARAM_INT);
                $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
                $stmt->execute();

                while ($row = $stmt->fetch()):
                ?>
                <tr>
                    <td><?= htmlspecialchars($row['title']) ?></td>
                    <td><span class="category-tag"><?= htmlspecialchars($row['category']) ?></span></td>
                    <td><?= date('M d, Y', strtotime($row['created_at'])) ?></td>
                    <td>
                        <a href="admin.php?edit=<?= $row['id'] ?>" style="color: blue; margin-right: 10px;">Edit</a>
                        <a href="admin.php?delete=<?= $row['id'] ?>" style="color: red;" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- PAGINATION LINKS -->
        <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="admin.php?page=<?= $page - 1 ?>">&laquo; Prev</a>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="admin.php?page=<?= $i ?>" class="<?= ($i == $page) ? 'active' : '' ?>">
                    <?= $i ?>
                </a>
            <?php endfor; ?>

            <?php if ($page < $total_pages): ?>
                <a href="admin.php?page=<?= $page + 1 ?>">Next &raquo;</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>

    </div>
</div>

<script>
    $(document).ready(function() {
        $('#summernote').summernote({
            placeholder: 'Write your blog post here...',
            tabsize: 2,
            height: 300,
            toolbar: [
              ['style', ['style']],
              ['font', ['bold', 'underline', 'clear']],
              ['color', ['color']],
              ['para', ['ul', 'ol', 'paragraph']],
              ['table', ['table']],
              ['insert', ['link', 'picture', 'video']],
              ['view', ['fullscreen', 'codeview', 'help']]
            ],
            callbacks: {
                onImageUpload: function(files) {
                    uploadImage(files[0]);
                }
            }
        });

        function uploadImage(file) {
            var data = new FormData();
            data.append("file", file);
            $.ajax({
                url: 'admin.php?upload_image=1',
                cache: false,
                contentType: false,
                processData: false,
                data: data,
                type: "POST",
                success: function(url) {
                    $('#summernote').summernote('insertImage', url);
                },
                error: function(data) {
                    console.log(data);
                    alert("Error uploading image");
                }
            });
        }
    });
</script>

</body>
</html>
