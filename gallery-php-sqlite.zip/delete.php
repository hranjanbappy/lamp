<?php
// delete.php
require_once 'config.php';

// Check if an ID was passed in the URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $image_id = (int)$_GET['id'];
    $pdo = get_db_connection();

    try {
        // 1. Fetch the filename from the database before deleting the record
        $stmt_select = $pdo->prepare("SELECT filename FROM images WHERE id = :id");
        $stmt_select->execute([':id' => $image_id]);
        $image = $stmt_select->fetch(PDO::FETCH_ASSOC);

        if ($image) {
            $filename = $image['filename'];
            $file_path = UPLOAD_DIR . $filename;

            // 2. Delete the record from the database
            $stmt_delete_db = $pdo->prepare("DELETE FROM images WHERE id = :id");
            $stmt_delete_db->execute([':id' => $image_id]);

            // 3. Delete the physical file from the server
            if (file_exists($file_path)) {
                unlink($file_path);
            }

            // Redirect back to the admin panel with a success message
            header('Location: admin.php?status=deleted');
            exit;

        } else {
            // Image not found in the database
            header('Location: admin.php?status=not_found');
            exit;
        }

    } catch (PDOException $e) {
        // Handle database errors
        header('Location: admin.php?status=error');
        exit;
    }
} else {
    // ID was not passed or was invalid
    header('Location: admin.php?status=invalid_id');
    exit;
}
?>
