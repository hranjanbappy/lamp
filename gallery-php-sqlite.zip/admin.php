<?php
// admin.php - UPDATED
require_once 'config.php';

$pdo = get_db_connection();
$message = '';
$base_url = rtrim(UPLOAD_DIR, '/');

// --- Handle Status Messages from Deletion ---
if (isset($_GET['status'])) {
    $status = $_GET['status'];
    if ($status == 'deleted') {
        $message = '<div class="alert alert-success">Image deleted successfully!</div>';
    } elseif ($status == 'not_found' || $status == 'invalid_id' || $status == 'error') {
        $message = '<div class="alert alert-danger">Error: Could not delete the image.</div>';
    }
}
// --- End Status Handling ---

// --- Image Upload Logic (Unchanged from previous response) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    $file = $_FILES['image'];

    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    if (!in_array($file['type'], $allowed_types)) {
        $message = '<div class="alert alert-danger">Error: Only JPG, PNG, and GIF files are allowed.</div>';
    } elseif ($file['error'] !== UPLOAD_ERR_OK) {
        $message = '<div class="alert alert-danger">Error uploading file: ' . $file['error'] . '</div>';
    } else {
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $safe_filename = uniqid('img_', true) . '.' . $extension;
        $destination = UPLOAD_DIR . $safe_filename;

        if (move_uploaded_file($file['tmp_name'], $destination)) {
            $stmt = $pdo->prepare("INSERT INTO images (filename) VALUES (:filename)");
            $stmt->execute([':filename' => $safe_filename]);
            $message = '<div class="alert alert-success">Image uploaded successfully!</div>';
        } else {
            $message = '<div class="alert alert-danger">Error moving uploaded file.</div>';
        }
    }
}
// --- End Upload Logic ---

// --- Pagination and Display Logic (Unchanged) ---
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$current_page = max(1, $current_page);

$count_stmt = $pdo->query("SELECT COUNT(*) FROM images");
$total_images = $count_stmt->fetchColumn();

$pagination = get_pagination_details($total_images, $current_page, IMAGES_PER_PAGE);

$limit = IMAGES_PER_PAGE;
$offset = $pagination['offset'];
$images_stmt = $pdo->prepare("SELECT id, filename, uploaded_at FROM images ORDER BY uploaded_at DESC LIMIT :limit OFFSET :offset");
$images_stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
$images_stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$images_stmt->execute();
$images = $images_stmt->fetchAll(PDO::FETCH_ASSOC);
// --- End Display Logic ---
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Gallery</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
</head>
<body>

<div class="container my-5">
    <h1 class="mb-4">🔑 Admin Panel</h1>
    <p><a href="index.php" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-eye"></i> View Gallery</a></p>

    <?php echo $message; ?>

    <div class="card mb-5">
        <div class="card-header">
            <h5 class="mb-0">Upload New Image</h5>
        </div>
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="image" class="form-label">Select Image File (JPG, PNG, GIF)</label>
                    <input class="form-control" type="file" id="image" name="image" accept=".jpg, .jpeg, .png, .gif" required>
                </div>
                <button type="submit" class="btn btn-success"><i class="fa-solid fa-upload"></i> Upload</button>
            </form>
        </div>
    </div>

    <h2>Uploaded Images (Page <?php echo $pagination['current_page']; ?> of <?php echo $pagination['total_pages']; ?>)</h2>

    <div class="row g-4 mb-4">
        <?php if (count($images) > 0): ?>
            <?php foreach ($images as $img):
                $image_path = $base_url . '/' . htmlspecialchars($img['filename']);
            ?>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card">
                        <img src="<?php echo $image_path; ?>" class="card-img-top" alt="Uploaded Image" style="height: 150px; object-fit: cover;">
                        <div class="card-body p-2">
                            <small class="text-muted d-block text-truncate"><?php echo htmlspecialchars($img['filename']); ?></small>
                            <small class="text-muted d-block">ID: <?php echo $img['id']; ?></small>

                            <a href="delete.php?id=<?php echo $img['id']; ?>"
                                class="btn btn-sm btn-danger w-100 mt-2"
                                onclick="return confirm('Are you sure you want to delete this image? This action cannot be undone.');">
                                <i class="fa-solid fa-trash"></i> Delete
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center">
                <p>No images uploaded yet.</p>
            </div>
        <?php endif; ?>
    </div>

    <?php if ($pagination['total_pages'] > 1): ?>
    <nav aria-label="Admin Page navigation">
        <ul class="pagination justify-content-center">
            <li class="page-item <?php echo ($pagination['current_page'] <= 1) ? 'disabled' : ''; ?>">
                <a class="page-link" href="?page=<?php echo $pagination['current_page'] - 1; ?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>

            <?php for ($i = 1; $i <= $pagination['total_pages']; $i++): ?>
                <li class="page-item <?php echo ($i == $pagination['current_page']) ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>

            <li class="page-item <?php echo ($pagination['current_page'] >= $pagination['total_pages']) ? 'disabled' : ''; ?>">
                <a class="page-link" href="?page=<?php echo $pagination['current_page'] + 1; ?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        </ul>
    </nav>
    <?php endif; ?>

</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
