<?php
require 'config.php';

// --- PAGINATION SETTINGS ---
$posts_per_page = 9; // Change this number to display more/less posts
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $posts_per_page;

// --- FILTERING & COUNTING ---
$category = isset($_GET['category']) ? $_GET['category'] : null;

// 1. Get Total Number of Posts (to calculate total pages)
if ($category) {
    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM posts WHERE category = ?");
    $countStmt->execute([$category]);
} else {
    $countStmt = $pdo->query("SELECT COUNT(*) FROM posts");
}
$total_posts = $countStmt->fetchColumn();
$total_pages = ceil($total_posts / $posts_per_page);

// 2. Get the Posts for the current page
if ($category) {
    $stmt = $pdo->prepare("SELECT * FROM posts WHERE category = ? ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
    $stmt->bindValue(':limit', $posts_per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->bindValue(1, $category, PDO::PARAM_STR); // Bind category manually
    $stmt->execute();
} else {
    $stmt = $pdo->prepare("SELECT * FROM posts ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
    $stmt->bindValue(':limit', $posts_per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
}

$posts = $stmt->fetchAll();
$pageTitle = $category ? "Category: " . htmlspecialchars($category) : "Recent Posts";

// Get all unique categories for the sidebar/menu
$catStmt = $pdo->query("SELECT DISTINCT category FROM posts ORDER BY category ASC");
$categories = $catStmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Blog</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Pagination Styles */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 2rem;
            gap: 5px;
        }
        .pagination a {
            background: #3498db;
            color: white;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9rem;
        }
        .pagination a:hover {
            background: #2980b9;
        }
        .pagination a.active {
            background: #2c3e50; /* Darker color for current page */
            font-weight: bold;
            pointer-events: none;
        }
        .pagination a.disabled {
            background: #bdc3c7;
            pointer-events: none;
            color: #ecf0f1;
        }
    </style>
</head>
<body>

<header>
    <div class="container">
        <nav>
            <h1><a href="index.php">My Awesome Blog</a></h1>
            <div>
                <?php foreach($categories as $cat): ?>
                    <a href="index.php?category=<?= urlencode($cat) ?>"><?= htmlspecialchars($cat) ?></a>
                <?php endforeach; ?>
                <a href="admin.php" style="background: rgba(255,255,255,0.2); padding: 5px 10px; border-radius: 4px;">Admin</a>
            </div>
        </nav>
    </div>
</header>

<div class="container">
    <?php if($category): ?>
        <div class="archive-header">
            <h2>Browsing Category: <?= htmlspecialchars($category) ?></h2>
            <a href="index.php" style="color: #777; text-decoration: none;">&larr; Back to all posts</a>
        </div>
    <?php endif; ?>

    <div class="blog-grid">
        <?php if (count($posts) > 0): ?>
            <?php foreach ($posts as $post): ?>
                <div class="post-card">
                    <?php if($post['thumbnail']): ?>
                        <img src="<?= htmlspecialchars($post['thumbnail']) ?>" alt="Thumbnail" class="post-thumbnail">
                    <?php else: ?>
                        <div class="post-thumbnail" style="display:flex;align-items:center;justify-content:center;color:#999;">No Image</div>
                    <?php endif; ?>

                    <div class="post-content">
                        <div class="post-meta">
                            <a href="index.php?category=<?= urlencode($post['category']) ?>" class="category-tag"><?= htmlspecialchars($post['category']) ?></a>
                            &nbsp; <?= date('M d, Y', strtotime($post['created_at'])) ?>
                        </div>
                        <h2 class="post-title">
                            <a href="post.php?id=<?= $post['id'] ?>"><?= htmlspecialchars($post['title']) ?></a>
                        </h2>
                        <p><?= substr(strip_tags($post['body']), 0, 100) ?>...</p>
                        <a href="post.php?id=<?= $post['id'] ?>" class="read-more">Read Article &rarr;</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No posts found. <a href="admin.php">Login to create one!</a></p>
        <?php endif; ?>
    </div>

    <!-- Pagination Controls -->
    <?php if ($total_pages > 1): ?>
    <div class="pagination">
        <!-- Previous Button -->
        <?php if ($page > 1): ?>
            <a href="?page=<?= $page - 1 ?><?= $category ? '&category=' . urlencode($category) : '' ?>">&larr; Prev</a>
        <?php else: ?>
            <a class="disabled">&larr; Prev</a>
        <?php endif; ?>

        <!-- Page Numbers -->
        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <a href="?page=<?= $i ?><?= $category ? '&category=' . urlencode($category) : '' ?>"
               class="<?= $i === $page ? 'active' : '' ?>">
                <?= $i ?>
            </a>
        <?php endfor; ?>

        <!-- Next Button -->
        <?php if ($page < $total_pages): ?>
            <a href="?page=<?= $page + 1 ?><?= $category ? '&category=' . urlencode($category) : '' ?>">Next &rarr;</a>
        <?php else: ?>
            <a class="disabled">Next &rarr;</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>

</div>

</body>
</html>
