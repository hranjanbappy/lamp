<?php
// index.php
require_once 'config.php';

$pdo = get_db_connection();

// 1. Get current page and calculate offset
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$current_page = max(1, $current_page); // Ensure page is at least 1

// 2. Count total number of images
$count_stmt = $pdo->query("SELECT COUNT(*) FROM images");
$total_images = $count_stmt->fetchColumn();

// 3. Get pagination details
$pagination = get_pagination_details($total_images, $current_page, IMAGES_PER_PAGE);

// 4. Fetch images for the current page
$limit = IMAGES_PER_PAGE;
$offset = $pagination['offset'];
$images_stmt = $pdo->prepare("SELECT filename FROM images ORDER BY uploaded_at DESC LIMIT :limit OFFSET :offset");
$images_stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
$images_stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$images_stmt->execute();
$images = $images_stmt->fetchAll(PDO::FETCH_ASSOC);

$base_url = rtrim(UPLOAD_DIR, '/');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Gallery</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        /* ... Your existing CSS styles ... */
        #gallery { padding-top: 40px; }
        @media screen and (min-width: 991px) { #gallery { padding: 60px 30px 0 30px; } }
        .img-wrapper { position: relative; margin-top: 15px; }
        .img-wrapper img { width: 100%; }
        .img-overlay { background: rgba(0, 0, 0, 0.7); width: 100%; height: 100%; position: absolute; top: 0; left: 0; display: flex; justify-content: center; align-items: center; opacity: 0; transition: opacity 0.6s; cursor: pointer; }
        .img-overlay i { color: #fff; font-size: 2em; }
        .img-wrapper:hover .img-overlay { opacity: 1; }
        #overlay { background: rgba(0, 0, 0, 0.9); width: 100%; height: 100%; position: fixed; top: 0; left: 0; display: flex; justify-content: center; align-items: center; z-index: 9999; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; }
        #overlay img { margin: 0; width: 90%; height: auto; max-height: 90vh; object-fit: contain; }
        @media screen and (min-width: 768px) { #overlay img { width: 60%; } }
        @media screen and (min-width: 1200px) { #overlay img { width: 50%; } }
        #nextButton, #prevButton { color: #fff; font-size: 3em; transition: all 0.3s; cursor: pointer; padding: 20px; user-select: none; position: absolute; z-index: 10001; background: rgba(0, 0, 0, 0.5); border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; top: 50%; transform: translateY(-50%); }
        #prevButton { left: 30px; }
        #nextButton { right: 30px; }
        #nextButton:hover, #prevButton:hover { background: rgba(255, 255, 255, 0.2); transform: translateY(-50%) scale(1.1); }
        @media screen and (min-width: 768px) { #nextButton, #prevButton { font-size: 3.5em; width: 80px; height: 80px; } }
        #exitButton { color: #fff; font-size: 2.5em; transition: all 0.3s; position: absolute; top: 20px; right: 20px; cursor: pointer; user-select: none; z-index: 10001; background: rgba(0, 0, 0, 0.5); border-radius: 50%; width: 60px; height: 60px; display: flex; align-items: center; justify-content: center; }
        #exitButton:hover { background: rgba(255, 255, 255, 0.2); transform: scale(1.1); }
        @media screen and (min-width: 768px) { #exitButton { font-size: 3em; width: 70px; height: 70px; } }
    </style>
</head>
<body>

<section id="gallery">
    <div class="container">
        <h1 class="text-center mb-4">Image Gallery</h1>
        <p class="text-end"><a href="admin.php" class="btn btn-sm btn-outline-secondary">Admin Panel</a></p>
        <div id="image-gallery">
            <div class="row g-4">
                <?php if (count($images) > 0): ?>
                    <?php foreach ($images as $img):
                        $image_path = $base_url . '/' . htmlspecialchars($img['filename']);
                    ?>
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 image">
                            <div class="img-wrapper">
                                <a href="<?php echo $image_path; ?>">
                                    <img src="<?php echo $image_path; ?>" class="img-fluid" alt="Gallery Image">
                                </a>
                                <div class="img-overlay">
                                    <i class="fa-solid fa-expand" aria-hidden="true"></i>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-12 text-center">
                        <p>No images found in the gallery.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($pagination['total_pages'] > 1): ?>
        <nav aria-label="Page navigation" class="mt-4">
            <ul class="pagination justify-content-center">
                <li class="page-item <?php echo ($pagination['current_page'] <= 1) ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $pagination['current_page'] - 1; ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>

                <?php for ($i = 1; $i <= $pagination['total_pages']; $i++): ?>
                    <li class="page-item <?php echo ($i == $pagination['current_page']) ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>

                <li class="page-item <?php echo ($pagination['current_page'] >= $pagination['total_pages']) ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $pagination['current_page'] + 1; ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</section>

<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<script>
    // ... Your existing JavaScript for the lightbox functionality ...
    $(document).ready(function() {
        $(".img-wrapper").hover( function() {}, function() {} );

        var $overlay = $('<div id="overlay"></div>');
        var $image = $("<img>");
        var $prevButton = $('<div id="prevButton"><i class="fa-solid fa-chevron-left"></i></div>');
        var $nextButton = $('<div id="nextButton"><i class="fa-solid fa-chevron-right"></i></div>');
        var $exitButton = $('<div id="exitButton"><i class="fa-solid fa-xmark"></i></div>');

        $overlay.append($image).append($prevButton).append($nextButton).append($exitButton);
        $("#gallery").append($overlay);

        $overlay.hide();

        var allImageHrefs = [];
        $("#image-gallery a").each(function() {
            allImageHrefs.push($(this).attr('href'));
        });

        $(".img-wrapper").click(function(event) {
            event.preventDefault();
            var imageLocation = $(this).find("a").attr("href");
            $image.attr("src", imageLocation);
            $overlay.fadeIn("slow");
            event.stopPropagation();
        });

        function updateImage(direction) {
            $("#overlay img").hide();

            var currentImgSrc = $("#overlay img").attr("src");
            var currentIndex = allImageHrefs.indexOf(currentImgSrc);
            var nextIndex;

            if (direction === 'next') {
                nextIndex = (currentIndex + 1) % allImageHrefs.length;
            } else if (direction === 'prev') {
                nextIndex = (currentIndex - 1 + allImageHrefs.length) % allImageHrefs.length;
            }

            var $newImageSrc = allImageHrefs[nextIndex];
            $("#overlay img").attr("src", $newImageSrc).fadeIn(800);
        }

        $nextButton.click(function(event) { updateImage('next'); event.stopPropagation(); });
        $prevButton.click(function(event) { updateImage('prev'); event.stopPropagation(); });

        $exitButton.click(function(event) { $("#overlay").fadeOut("slow"); event.stopPropagation(); });

        $overlay.click(function(event) {
            if (event.target === this) {
                $(this).fadeOut("slow");
            }
        });

        $(document).keydown(function(event) {
            if ($overlay.is(":visible")) {
                if (event.key === "ArrowRight") {
                    updateImage('next');
                } else if (event.key === "ArrowLeft") {
                    updateImage('prev');
                } else if (event.key === "Escape") {
                    $("#overlay").fadeOut("slow");
                }
            }
        });
    });
</script>

</body>
</html>
