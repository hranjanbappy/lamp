<?php
require 'config.php';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
$stmt->execute([$_GET['id']]);
$post = $stmt->fetch();

if (!$post) {
    die("Post not found!");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($post['title']) ?> - My Blog</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <div class="container">
        <nav>
            <h1><a href="index.php">My Awesome Blog</a></h1>
            <a href="index.php">Home</a>
        </nav>
    </div>
</header>

<div class="container">
    <div class="single-post-container">
        <span class="category-tag"><?= htmlspecialchars($post['category']) ?></span>
        <h1 style="margin-top: 10px; font-size: 2.5rem;"><?= htmlspecialchars($post['title']) ?></h1>
        <p class="post-meta">Published on <?= date('F d, Y', strtotime($post['created_at'])) ?></p>

        <?php if($post['thumbnail']): ?>
            <img src="<?= htmlspecialchars($post['thumbnail']) ?>" class="single-post-img" alt="Cover Image">
        <?php endif; ?>

        <div class="post-body">
            <!-- We echo body directly to allow HTML from the WYSIWYG editor -->
            <!-- In production, consider using HTMLPurifier here for security -->
            <?= $post['body'] ?>
        </div>

        <hr style="margin: 2rem 0; border: 0; border-top: 1px solid #eee;">
        <a href="index.php">&larr; Back to Home</a>
    </div>
</div>

</body>
</html>
